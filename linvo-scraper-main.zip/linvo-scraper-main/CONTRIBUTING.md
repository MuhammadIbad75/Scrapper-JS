# How to contribute to Linvo

## Setup

1. Clone the project
2. Install using "npm install"
3. Go to the lib folder and copy the file test.example.ts to test.ts
4. Write a new LinkedIn service and test it inside of test.ts 
5. Run your test with "npm run start"

## Building

Run "npm run build"